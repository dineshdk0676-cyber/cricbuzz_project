# Cricbuzz LiveStats

A Streamlit cricket analytics dashboard based on the requirements in `Cricbuzz.docx`. It includes Cricbuzz live-match API integration, real international ball-by-ball historical scorecards, player leaderboards, 25 SQL analytics exercises, and player/match CRUD backed by SQLite.

> **Historical data:** The default database is populated from Cricsheet's men's international Test, ODI, and T20I ball-by-ball archives. This is real historical scorecard data, not Cricbuzz live data. Live match snapshots are saved only after a successful Cricbuzz API request.

## Features

- Home page and multi-page Streamlit navigation.
- Optional live matches via the Cricbuzz Cricket API on RapidAPI.
- Top run scorers and wicket takers by format.
- The 25 beginner, intermediate, and advanced SQL exercises described in the brief.
- Read-only custom `SELECT`/`WITH` query runner.
- Create, read, update, and delete player and match records.
- SQLite schema with foreign keys, data validation, and indexes.

## Requirements and setup

Python 3.10 or newer is recommended.

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
Copy-Item .env.example .env
python -m streamlit run app.py
```

The initialized historical database is `data/cricbuzz_real.db`. The app creates the schema automatically if needed, but will not silently populate this real-data database with synthetic records if it is empty. To select another database, set `CRICBUZZ_DB_PATH`. The earlier `data/cricbuzz.db` synthetic demo database is retained separately and is not used by default.

## Enable live data

1. Create an account and subscription for a Cricbuzz Cricket API provider on RapidAPI.
2. Copy `.env.example` to `.env` and set `CRICBUZZ_API_KEY` to your own key.
3. If your provider uses a different host or live endpoint, set `CRICBUZZ_API_HOST` and `CRICBUZZ_LIVE_PATH`.
4. Open **Live Matches** and choose **Refresh live matches**.

Keys can alternatively be supplied through Streamlit secrets. Do not commit `.env` or `secrets.toml`. This project does not include or distribute an API key. Provider availability, pricing, quotas, endpoint access, and response format are controlled by the provider.

The API page deliberately displays the response from the configured endpoint instead of assuming all providers return the same JSON structure. It reports missing credentials and request/response errors rather than presenting demo records as live data.

## Database and SQL

The schema is in `database/schema.sql`; `utils/seed_data.py` supplies synthetic demo records only for an empty database. `scripts/import_cricsheet.py` imports the downloaded Cricsheet archives into a new `data/cricbuzz_real.db` and refuses to overwrite an existing database. The canonical query definitions are in `utils/analytics_queries.py`.

The full working folder also contains the source archives `data/tests_male_json.zip`, `data/odis_male_json.zip`, and `data/it20s_male_json.zip`. They contain 3,732 men's international matches in the downloaded release: 896 Tests, 2,596 ODIs, and 240 T20Is. The shareable project ZIP contains the initialized database but omits those original archives to keep the upload smaller. To re-import from source, download the three archives from the links below, place them in `data/`, rename/remove `data/cricbuzz_real.db`, and run `python scripts/import_cricsheet.py`.

The SQL queries are written for SQLite and make explicit assumptions where the source brief leaves definitions open:

- Batting average is total runs divided by dismissals; strike rate is runs per 100 balls.
- Bowling economy is runs conceded per six legal balls.
- The partnership exercises identify adjacent batting positions and sum those batters' individual runs; this is a simplified proxy, not ball-by-ball partnership scoring.
- Form categories and the career-trend threshold are illustrative analytics rules and can be adjusted for a real dataset.
- The performance-ranking formula follows the brief's weights, correcting the extra parenthesis in its bowling-points expression. Missing components contribute zero.
- Cricsheet does not provide player roles/styles, venue capacities, or a consistent venue country for these records. Such biography/location fields are left unknown rather than invented, so queries depending on them can have incomplete or empty results.

The custom SQL runner accepts one read-only `SELECT` or `WITH` statement. It is not intended for untrusted multi-user environments.

## Project layout

```text
app.py
pages/
  1_Live_Matches.py
  2_Top_Player_Stats.py
  3_SQL_Analytics.py
  4_CRUD_Operations.py
utils/
  analytics_queries.py
  api_client.py
  db_connection.py
  seed_data.py
scripts/
  import_cricsheet.py
database/
  schema.sql
data/
  cricbuzz_real.db     # downloaded historical match data
  cricbuzz.db          # older synthetic demo database
tests/
```

## Limitations and production considerations

- SQLite is the initial supported database. The document mentions PostgreSQL/MySQL too, but true database portability requires separate driver/configuration testing.
- API authentication and endpoints can vary by RapidAPI provider. Use the provider's current endpoint documentation and your own subscription.
- Cricsheet historical records are ball-by-ball data, but they are not an official Cricbuzz feed. Use the live API page for current match snapshots.
- Add authentication/authorization and audit logging before exposing CRUD outside a trusted local environment.
- Betting-related analysis in the brief is historical analysis only and does not guarantee match outcomes.

## Historical data source and attribution

Historical data was downloaded from [Cricsheet Downloads](https://cricsheet.org/downloads/) on 2026-10-19:

- [Men's Test JSON archive](https://cricsheet.org/downloads/tests_male_json.zip)
- [Men's ODI JSON archive](https://cricsheet.org/downloads/odis_male_json.zip)
- [Men's T20I JSON archive](https://cricsheet.org/downloads/it20s_male_json.zip)

Cricsheet data is licensed under the [Open Data Commons Attribution License (ODC-By 1.0)](https://opendatacommons.org/licenses/by/1.0/). Source JSON was transformed into relational match, batting, bowling, and fielding tables; attribution is retained here. Review the full license and Cricsheet's terms before redistributing or making public use of the data.
